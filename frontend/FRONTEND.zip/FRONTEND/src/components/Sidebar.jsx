function Sidebar({ pagina, setPagina }) {
    return (
        <aside className="sidebar">
            <div className="sidebar-header">
                <h2>Edu IA</h2>
                <p>Menu principal</p>
            </div>

            <nav className="sidebar-nav">
                <button
                    className={pagina === "dashboard" ? "active" : ""}
                    onClick={() => setPagina("dashboard")}
                >
                    Dashboard
                </button>

                <button
                    className={pagina === "trilhas" ? "active" : ""}
                    onClick={() => setPagina("trilhas")}
                >
                    Trilhas
                </button>

                <button
                    className={pagina === "avaliacao" ? "active" : ""}
                    onClick={() => setPagina("avaliacao")}
                >
                    Avaliação
                </button>

                <button
                    className={pagina === "planos" ? "active" : ""}
                    onClick={() => setPagina("planos")}
                >
                    Planos
                </button>

                <button
                    className={pagina === "perfil" ? "active" : ""}
                    onClick={() => setPagina("perfil")}
                >
                    Perfil
                </button>
            </nav>
        </aside>
    );
}

export default Sidebar;