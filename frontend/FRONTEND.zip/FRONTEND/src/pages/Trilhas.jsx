import { useEffect, useState } from "react";
import { apiFetch } from "../services/api";

function Trilhas() {
    const [form, setForm] = useState({
        areaInteresse: "",
        nivelAtual: "iniciante",
        nivelObjetivo: "intermediario"
    });

    const [opcoes, setOpcoes] = useState([]);
    const [minhaTrilha, setMinhaTrilha] = useState(null);
    const [mensagem, setMensagem] = useState("");
    const [erro, setErro] = useState("");
    const [carregando, setCarregando] = useState(false);

    useEffect(() => {
        carregarMinhaTrilha();
    }, []);

    async function carregarMinhaTrilha() {
        try {
            const data = await apiFetch("/trilhas/minha");
            setMinhaTrilha(data.trilha || null);
        } catch (error) {
            console.error(error.message);
        }
    }

    function handleChange(event) {
        const { name, value } = event.target;

        setForm((prev) => ({
            ...prev,
            [name]: value
        }));
    }

    async function gerarOpcoes(event) {
        event.preventDefault();
        setMensagem("");
        setErro("");
        setCarregando(true);

        try {
            const data = await apiFetch("/trilhas/gerar-opcoes", {
                method: "POST",
                body: JSON.stringify(form)
            });

            setOpcoes(data.opcoes || []);
            setMensagem("Opções de trilha geradas com sucesso.");
        } catch (error) {
            setErro(error.message);
        } finally {
            setCarregando(false);
        }
    }

    async function escolherTrilha(trilha) {
        setMensagem("");
        setErro("");

        try {
            const data = await apiFetch("/trilhas/escolher", {
                method: "POST",
                body: JSON.stringify(trilha)
            });

            setMinhaTrilha(data.trilha);
            setMensagem("Trilha escolhida com sucesso.");
        } catch (error) {
            setErro(error.message);
        }
    }

    return (
        <div className="page-content">
            <div className="page-header">
                <div>
                    <h1>Trilhas com IA</h1>
                    <p>
                        Informe seu nível atual, o nível que deseja alcançar e a
                        área de interesse para a Gemini gerar opções personalizadas.
                    </p>
                </div>
            </div>

            <section className="card">
                <h3>Gerar opções de trilha</h3>

                <form onSubmit={gerarOpcoes}>
                    <div className="form-group">
                        <label htmlFor="areaInteresse">Área de interesse</label>
                        <input
                            id="areaInteresse"
                            name="areaInteresse"
                            value={form.areaInteresse}
                            onChange={handleChange}
                            placeholder="Ex: JavaScript, Banco de Dados, Redes..."
                            required
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="nivelAtual">Onde estou</label>
                        <select
                            id="nivelAtual"
                            name="nivelAtual"
                            value={form.nivelAtual}
                            onChange={handleChange}
                        >
                            <option value="iniciante">Iniciante</option>
                            <option value="intermediario">Intermediário</option>
                            <option value="avancado">Avançado</option>
                        </select>
                    </div>

                    <div className="form-group">
                        <label htmlFor="nivelObjetivo">Onde quero chegar</label>
                        <select
                            id="nivelObjetivo"
                            name="nivelObjetivo"
                            value={form.nivelObjetivo}
                            onChange={handleChange}
                        >
                            <option value="iniciante">Iniciante</option>
                            <option value="intermediario">Intermediário</option>
                            <option value="avancado">Avançado</option>
                        </select>
                    </div>

                    <button type="submit" disabled={carregando}>
                        {carregando ? "Gerando..." : "Gerar trilhas com IA"}
                    </button>
                </form>

                {mensagem && <p className="msg success">{mensagem}</p>}
                {erro && <p className="msg error">{erro}</p>}
            </section>

            {minhaTrilha && (
                <section className="card">
                    <h3>Minha trilha atual</h3>
                    <div className="plan-item">
                        <div>
                            <strong>{minhaTrilha.titulo}</strong>
                            <p>{minhaTrilha.descricao}</p>
                            <p>
                                <strong>Onde estou:</strong> {minhaTrilha.nivelAtual}
                            </p>
                            <p>
                                <strong>Onde quero chegar:</strong> {minhaTrilha.nivelObjetivo}
                            </p>
                        </div>
                    </div>
                </section>
            )}

            <section className="card">
                <h3>Opções geradas</h3>

                {opcoes.length === 0 ? (
                    <p className="empty-text">
                        Nenhuma trilha gerada ainda. Preencha os dados acima.
                    </p>
                ) : (
                    <div className="plans-list">
                        {opcoes.map((trilha, index) => (
                            <div className="plan-item" key={index}>
                                <div>
                                    <strong>{trilha.titulo}</strong>
                                    <p>{trilha.descricao}</p>
                                    <p>
                                        <strong>Tópicos:</strong>{" "}
                                        {(trilha.topicos || []).join(", ")}
                                    </p>
                                    <p>
                                        <strong>Habilidades:</strong>{" "}
                                        {(trilha.habilidades || []).join(", ")}
                                    </p>
                                    <p>
                                        <strong>Onde estou:</strong> {trilha.nivelAtual}
                                    </p>
                                    <p>
                                        <strong>Onde quero chegar:</strong> {trilha.nivelObjetivo}
                                    </p>
                                </div>

                                <button onClick={() => escolherTrilha(trilha)}>
                                    Escolher
                                </button>
                            </div>
                        ))}
                    </div>
                )}
            </section>
        </div>
    );
}

export default Trilhas;