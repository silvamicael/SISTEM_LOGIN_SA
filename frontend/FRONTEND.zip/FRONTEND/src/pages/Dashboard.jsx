import { useEffect, useState } from "react";
import { apiFetch } from "../services/api";

function Dashboard() {
    const [usuario, setUsuario] = useState(null);
    const [planos, setPlanos] = useState([]);
    const [erro, setErro] = useState("");

    useEffect(() => {
        carregarDados();
    }, []);

    async function carregarDados() {
        try {
            const [perfil, listaPlanos] = await Promise.all([
                apiFetch("/usuario/perfil"),
                apiFetch("/plans")
            ]);

            setUsuario(perfil);
            setPlanos(Array.isArray(listaPlanos) ? listaPlanos : []);
        } catch (error) {
            setErro(error.message);
        }
    }

    return (
        <div className="page-content">
            <div className="page-header">
                <div>
                    <h1>Dashboard</h1>
                    <p>Resumo geral da sua plataforma de aprendizagem.</p>
                </div>
            </div>

            {erro && <p className="msg error">{erro}</p>}

            <div className="dashboard-grid">
                <div className="dashboard-card">
                    <h3>Usuário</h3>
                    <p>{usuario?.nome || "-"}</p>
                </div>

                <div className="dashboard-card">
                    <h3>E-mail</h3>
                    <p>{usuario?.email || "-"}</p>
                </div>

                <div className="dashboard-card">
                    <h3>Status</h3>
                    <p className="status-active">
                        {usuario?.ativo ? "Ativo" : "Inativo"}
                    </p>
                </div>

                <div className="dashboard-card">
                    <h3>Planos cadastrados</h3>
                    <p>{planos.length}</p>
                </div>
            </div>

            <section className="card">
                <h3>Resumo do sistema</h3>
                <div className="info-list">
                    <p><strong>Autenticação:</strong> JWT ativa</p>
                    <p><strong>Banco:</strong> Supabase/PostgreSQL</p>
                    <p><strong>IA:</strong> Gemini integrada</p>
                    <p><strong>Frontend:</strong> React + Vite</p>
                </div>
            </section>
        </div>
    );
}

export default Dashboard;